# Saul King — Android app

Study app for **SAUL — ISRAEL'S FIRST KING (Group 8)**, packaged like LitReader:

* WebView wrapper around `app/src/main/assets/www/index.html` (fully offline)
* **Fixed 510dp layout** — `width=510` viewport + `UseWideViewPort` + `LoadWithOverviewMode` + `setInitialScale(dpW*100/510)` + `enforceFixedViewport()` — same as LitReader, so changing smallest-width to 400dp never reshapes the app
* **Immersive mode** — sticky fullscreen, status+nav hidden, swipe to peek, re-applied on focus/resume (`com.saulking.app.IMMERSIVE=true`)
* **Edge-to-edge** + inset bridge (`--saul-inset-top/bottom`, also `--yue-*` for compat)
* Manifest flags (no Java edits needed):
  `com.saulking.app.IMMERSIVE`, `com.saulking.app.EDGE_TO_EDGE`,
  `com.saulking.app.DARK_MODE`, `com.saulking.app.PULL_REFRESH`,
  `com.saulking.app.DESKTOP_SITE` — `true/false` or `1/0`

## Build it in the cloud (recommended)

1. Create a free GitHub account + new empty repo.
2. Upload **the contents of this folder** (`settings.gradle`, `build.gradle`, `app/`, …) to the repo root, so `settings.gradle` sits at `/`.
3. Open **Actions → Build Saul APK** → runs on push, or Run workflow. Wait 5–10 min.
4. Download `saul-apk` artifact, copy to phone, tap to install (allow unknown apps once).

All builds sign with `saul-debug.p12` in repo root — keep it, so updates install over the old app without uninstall.

## Update content

Edit `app/src/main/assets/www/index.html` (+ images in `www/img/`), commit, rebuild, install new APK over old — same app, same data.

To wrap a URL instead of the bundle, add:
`<meta-data android:name="com.saulking.app.URL" android:value="https://…"/>`
It wins over the bundled file.

## Local build

Android Studio → Open → this folder → sync → Run. Same APK.
