package com.studypal.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

/**
 * StudyPal AI app — same display core as LitReader:
 *  - fixed 510 CSS px layout (viewport width=510 + overview + initialScale)
 *  - immersive sticky fullscreen (status + nav hidden, swipe to peek)
 *  - edge-to-edge optional with system-bar insets pushed to the page as CSS vars
 *  - flags via manifest meta-data so builds can flip them without Java edits
 *
 * Wraps the online StudyPal generator (AI needs internet).
 * Local asset page is the offline fallback with a retry button.
 */
public class MainActivity extends Activity {

    private static final String ONLINE_URL = "https://perchance.org/studypal2";
    private static final String OFFLINE_URL = "file:///android_asset/www/index.html";

    private WebView web;
    private SwipeRefreshLayout pull;
    private ValueCallback<Uri[]> fileChooser;
    private boolean immersive;
    private long lastBackPress = 0;
    private int insetTopCss = 0, insetBottomCss = 0;
    private boolean showingFallback = false;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);

        immersive = metaBool("com.studypal.app.IMMERSIVE", "com.saulking.app.IMMERSIVE", "com.yuedu.app.IMMERSIVE", false);
        boolean edge = metaBool("com.studypal.app.EDGE_TO_EDGE", "com.saulking.app.EDGE_TO_EDGE", "com.yuedu.app.EDGE_TO_EDGE", false);
        boolean dark = metaBool("com.studypal.app.DARK_MODE", "com.saulking.app.DARK_MODE", "com.yuedu.app.DARK_MODE", false);
        boolean desktop = metaBool("com.studypal.app.DESKTOP_SITE", "com.saulking.app.DESKTOP_SITE", "com.yuedu.app.DESKTOP_SITE", false);
        boolean refresh = metaBool("com.studypal.app.PULL_REFRESH", "com.saulking.app.PULL_REFRESH", "com.yuedu.app.PULL_REFRESH", false);

        if (edge) applyEdgeToEdge();

        web = new WebView(this);
        web.setFitsSystemWindows(false);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        // Fixed 510 layout: honors width=510 viewport on every device / smallest-width.
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        if (desktop) {
            s.setUserAgentString("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36");
        } else {
            try {
                String ua = s.getUserAgentString();
                if (ua != null && ua.contains("; wv")) s.setUserAgentString(ua.replace("; wv", ""));
            } catch (Throwable ignored) {}
        }
        if (dark) applyDark(s);
        // First paint already at 510-fit scale (avoids 1s of huge text then shrink).
        try {
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            float dpW = dm.widthPixels / dm.density;
            int pct = Math.round(dpW * 100f / 510f);
            if (pct < 10) pct = 10; else if (pct > 500) pct = 500;
            web.setInitialScale(pct);
        } catch (Throwable ignored) {}

        if (refresh) {
            pull = new SwipeRefreshLayout(this);
            pull.addView(web, new SwipeRefreshLayout.LayoutParams(
                    SwipeRefreshLayout.LayoutParams.MATCH_PARENT,
                    SwipeRefreshLayout.LayoutParams.MATCH_PARENT));
            pull.setOnRefreshListener(() -> { if (web != null) web.reload(); });
            setContentView(pull);
        } else {
            setContentView(web);
        }
        if (immersive) applyImmersive();
        setupInsetBridge();

        CookieManager cm = CookieManager.getInstance();
        try { cm.setAcceptCookie(true); } catch (Throwable ignored) {}
        try { cm.setAcceptThirdPartyCookies(web, true); } catch (Throwable ignored) {}

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return false; }
            @Override public void onPageFinished(WebView v, String url) {
                super.onPageFinished(v, url);
                enforceFixedViewport(v);
                pushStoredInsets();
                if (pull != null) pull.setRefreshing(false);
            }
            @Override public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                // Bundle boots from file://; a main-frame error here means the
                // asset itself failed — nothing to fall back to, so do nothing
                // (avoids a reload loop). Online AI/fetch failures are shown
                // inline by the page with its own retry.
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) {
                if (pull != null && p == 100) pull.setRefreshing(false);
            }
            @Override public void onPermissionRequest(android.webkit.PermissionRequest request) {
                try { request.grant(request.getResources()); }
                catch (Throwable t) { try { super.onPermissionRequest(request); } catch (Throwable ignored) {} }
            }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileChooser != null) { try { fileChooser.onReceiveValue(null); } catch (Throwable ignored) {} }
                fileChooser = cb;
                try {
                    Intent i = p.createIntent();
                    startActivityForResult(i, 1001);
                } catch (Throwable t) {
                    fileChooser = null;
                    return false;
                }
                return true;
            }
        });

        web.setDownloadListener(new android.webkit.DownloadListener() {
            @Override public void onDownloadStart(String url, String userAgent,
                    String contentDisposition, String mimetype, long contentLength) {
                handleDownload(url, contentDisposition, mimetype);
            }
        });

        try {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.RECORD_AUDIO}, 2001);
            }
        } catch (Throwable ignored) {}

        String start = startUrl();
        try { web.loadUrl(start); } catch (Throwable ignored) {}
    }

    private String startUrl() {
        try {
            android.content.pm.ApplicationInfo ai = getPackageManager()
                    .getApplicationInfo(getPackageName(),
                            android.content.pm.PackageManager.GET_META_DATA);
            if (ai.metaData != null) {
                for (String k : new String[]{"com.studypal.app.URL", "com.saulking.app.URL", "com.yuedu.app.URL"}) {
                    String u = ai.metaData.getString(k);
                    if (u != null && (u.startsWith("https://") || u.startsWith("http://") || u.startsWith("file:///"))) return u;
                }
            }
        } catch (Throwable ignored) {}
        return OFFLINE_URL;
    }

    /** Called from the offline page's Retry button. */
    @android.webkit.JavascriptInterface
    public void retryOnline() {
        try {
            runOnUiThread(() -> {
                showingFallback = false;
                try { web.loadUrl(ONLINE_URL); } catch (Throwable ignored) {}
            });
        } catch (Throwable ignored) {}
    }

    private void enforceFixedViewport(WebView v) {
        if (v == null) return;
        try {
            v.evaluateJavascript(
                    "(function(){try{var m=document.querySelector('meta[name=viewport]');"
                            + "if(!m){m=document.createElement('meta');m.setAttribute('name','viewport');"
                            + "(document.head||document.documentElement).appendChild(m);}"
                            + "var c=m.getAttribute('content')||'';"
                            + "if(!/(^|,)\\s*width\\s*=\\s*510(\\s|,|$)/.test(c)){"
                            + "m.setAttribute('content','width=510, user-scalable=no, viewport-fit=cover');}"
                            + "return 1;}catch(e){return 0;}})();", null);
        } catch (Throwable ignored) {}
    }

    private void setupInsetBridge() {
        if (web == null) return;
        try {
            web.setOnApplyWindowInsetsListener((v, insets) -> {
                try { pushInsetsToPage(insets); } catch (Throwable ignored) {}
                return v.onApplyWindowInsets(insets);
            });
            web.requestApplyInsets();
        } catch (Throwable ignored) {}
        try { web.addJavascriptInterface(this, "StudyPalNative"); } catch (Throwable ignored) {}
    }

    private void pushInsetsToPage(android.view.WindowInsets insets) {
        try {
            android.view.WindowInsets root = null;
            try { root = getWindow().getDecorView().getRootWindowInsets(); } catch (Throwable ignored) {}
            if (root == null) root = insets;
            if (root == null) return;
            int topPx, bottomPx;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets stb = root.getInsets(android.view.WindowInsets.Type.statusBars());
                android.graphics.Insets nvb = root.getInsets(android.view.WindowInsets.Type.navigationBars());
                android.graphics.Insets tap = root.getInsets(android.view.WindowInsets.Type.tappableElement());
                topPx = Math.max(stb.top, tap.top);
                bottomPx = Math.max(nvb.bottom, tap.bottom);
            } else {
                topPx = root.getStableInsetTop();
                bottomPx = root.getStableInsetBottom();
            }
            int viewW = 0;
            try { viewW = web.getWidth(); } catch (Throwable ignored) {}
            if (viewW <= 0) { try { viewW = getResources().getDisplayMetrics().widthPixels; } catch (Throwable ignored) {} }
            if (viewW <= 0) return;
            double k = 510.0 / (double) viewW;
            insetTopCss = (int) Math.round(topPx * k);
            insetBottomCss = (int) Math.round(bottomPx * k);
            pushStoredInsets();
        } catch (Throwable ignored) {}
    }

    private void pushStoredInsets() {
        if (web == null) return;
        final int t = insetTopCss, b = insetBottomCss;
        final String js = "(function(){try{"
                + "document.documentElement.style.setProperty('--yue-inset-top','" + t + "px');"
                + "document.documentElement.style.setProperty('--yue-inset-bottom','" + b + "px');"
                + "document.documentElement.style.setProperty('--saul-inset-top','" + t + "px');"
                + "document.documentElement.style.setProperty('--saul-inset-bottom','" + b + "px');"
                + "return 1;}catch(e){return 0;}})();";
        try { web.evaluateJavascript(js, null); } catch (Throwable ignored) {}
    }

    private void applyEdgeToEdge() {
        try {
            Window w = getWindow();
            w.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            if (Build.VERSION.SDK_INT >= 28) {
                WindowManager.LayoutParams a = w.getAttributes();
                a.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                w.setAttributes(a);
            }
            if (Build.VERSION.SDK_INT >= 30) {
                getWindow().setDecorFitsSystemWindows(false);
            } else {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            }
        } catch (Throwable ignored) {}
    }

    private void applyImmersive() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                if (getWindow().getInsetsController() != null) {
                    getWindow().getInsetsController().hide(
                            android.view.WindowInsets.Type.statusBars()
                                    | android.view.WindowInsets.Type.navigationBars());
                    getWindow().getInsetsController().setSystemBarsBehavior(
                            android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
            } else {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                | View.SYSTEM_UI_FLAG_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            }
        } catch (Throwable ignored) {}
    }

    private void applyDark(WebSettings s) {
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                s.setAlgorithmicDarkeningAllowed(true);
            } else if (Build.VERSION.SDK_INT >= 29) {
                s.setForceDark(WebSettings.FORCE_DARK_ON);
            }
        } catch (Throwable ignored) {}
    }

    private boolean metaBool(String a, String b, String c, boolean def) {
        for (String name : new String[]{a, b, c}) {
            try {
                android.os.Bundle m = getPackageManager()
                        .getApplicationInfo(getPackageName(),
                                android.content.pm.PackageManager.GET_META_DATA).metaData;
                if (m != null && m.containsKey(name)) {
                    Object v = m.get(name);
                    if (v instanceof Boolean) return (Boolean) v;
                    if (v instanceof String) return Boolean.parseBoolean((String) v);
                    if (v instanceof Integer) return (Integer) v != 0;
                }
            } catch (Throwable ignored) {}
        }
        return def;
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && immersive) applyImmersive();
    }

    @Override protected void onResume() {
        super.onResume();
        if (immersive) applyImmersive();
        try { if (web != null) web.onResume(); } catch (Throwable ignored) {}
    }

    @Override protected void onPause() {
        try { if (web != null) web.onPause(); } catch (Throwable ignored) {}
        super.onPause();
    }

    @Override protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == 1001 && fileChooser != null) {
            try {
                Uri[] res = WebChromeClient.FileChooserParams.parseResult(result, data);
                fileChooser.onReceiveValue(res);
            } catch (Throwable t) {
                try { fileChooser.onReceiveValue(null); } catch (Throwable ignored) {}
            }
            fileChooser = null;
        }
    }

    /** Export button in the page triggers a download (JSON backup). Blob URLs
        cannot go through DownloadManager, so the blob is read back through
        the WebView and saved to Downloads. */
    private void handleDownload(final String url, final String contentDisposition, final String mimetype) {
        try {
            if (url != null && url.startsWith("blob:")) {
                final String q = org.json.JSONObject.quote(url);
                web.evaluateJavascript(
                        "(async()=>{try{const r=await fetch(" + q + ");const b=await r.blob();"
                        + "const fr=new FileReader();"
                        + "return await new Promise(res=>{fr.onload=()=>res(fr.result);fr.onerror=()=>res('');fr.readAsDataURL(b);});"
                        + "}catch(e){return '';}})();",
                        new ValueCallback<String>() {
                            @Override public void onReceiveValue(String v) { saveDataUrl(v, contentDisposition, mimetype); }
                        });
                return;
            }
            android.app.DownloadManager.Request req =
                    new android.app.DownloadManager.Request(Uri.parse(url));
            try { req.setMimeType(mimetype); } catch (Throwable ignored) {}
            String name = "studypal-export";
            try { name = android.webkit.URLUtil.guessFileName(url, contentDisposition, mimetype); } catch (Throwable ignored) {}
            try { req.setTitle(name); } catch (Throwable ignored) {}
            try { req.setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED); } catch (Throwable ignored) {}
            try { req.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, name); } catch (Throwable ignored) {}
            android.app.DownloadManager dm =
                    (android.app.DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            if (dm != null) dm.enqueue(req);
            try { Toast.makeText(MainActivity.this, "Downloading " + name, Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) {}
        } catch (Throwable t) {
            try { Toast.makeText(MainActivity.this, "Download failed", Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) {}
        }
    }

    private void saveDataUrl(String dataUrl, String contentDisposition, String mimetype) {
        try {
            if (dataUrl == null || dataUrl.length() < 5) throw new Exception("empty");
            if (dataUrl.startsWith("\"") && dataUrl.endsWith("\"") && dataUrl.length() > 1) {
                dataUrl = new org.json.JSONTokener(dataUrl).nextString();
            }
            int comma = dataUrl.indexOf(",");
            if (comma < 0) throw new Exception("bad data url");
            String meta = dataUrl.substring(0, comma);
            String b64 = dataUrl.substring(comma + 1);
            byte[] bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
            String ext = ".json";
            if (meta.contains("text/csv")) ext = ".csv";
            else if (meta.contains("text/plain")) ext = ".txt";
            String name = "studypal-" + new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(new java.util.Date()) + ext;
            if (Build.VERSION.SDK_INT >= 29) {
                android.content.ContentValues cv = new android.content.ContentValues();
                cv.put(android.provider.MediaStore.Downloads.DISPLAY_NAME, name);
                cv.put(android.provider.MediaStore.Downloads.MIME_TYPE, mimetype != null ? mimetype : "application/json");
                cv.put(android.provider.MediaStore.Downloads.IS_PENDING, 1);
                android.net.Uri col = android.provider.MediaStore.Downloads.getContentUri(android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY);
                android.net.Uri item = getContentResolver().insert(col, cv);
                if (item == null) throw new Exception("media store");
                try {
                    java.io.OutputStream os = getContentResolver().openOutputStream(item);
                    if (os == null) throw new Exception("stream");
                    os.write(bytes); os.close();
                } catch (Throwable t) {
                    try { getContentResolver().delete(item, null, null); } catch (Throwable ignored) {}
                    throw t;
                }
                cv.clear();
                cv.put(android.provider.MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(item, cv, null, null);
            } else {
                if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this,
                            new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2002);
                    Toast.makeText(this, "Allow storage, then tap export again", Toast.LENGTH_LONG).show();
                    return;
                }
                java.io.File dir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists()) dir.mkdirs();
                java.io.FileOutputStream fos = new java.io.FileOutputStream(new java.io.File(dir, name));
                fos.write(bytes); fos.close();
            }
            try { Toast.makeText(this, "Saved " + name + " to Downloads", Toast.LENGTH_LONG).show(); } catch (Throwable ignored) {}
        } catch (Throwable t) {
            try { Toast.makeText(this, "Export failed", Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) {}
        }
    }

    @Override public void onBackPressed() {
        try {
            if (web != null && web.canGoBack()) { web.goBack(); return; }
        } catch (Throwable ignored) {}
        long now = System.currentTimeMillis();
        if (now - lastBackPress < 2000) { super.onBackPressed(); return; }
        lastBackPress = now;
        try { Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show(); }
        catch (Throwable ignored) {}
    }

    @Override protected void onDestroy() {
        if (web != null) { try { web.destroy(); } catch (Throwable ignored) {} }
        super.onDestroy();
    }
}
