# StudyPal AI — Android app

Your Perchance generator as a real, self-contained app — same pattern as LitReader wrapping its reader (but fully bundled, no live page):

* The **entire generator is inside the APK** (`assets/www/index.html` + styles): subjects, AI flashcards, looping deck, quiz, guide, podcast, tutor, import/export
* No perchance.org page is ever loaded. AI runs through a built-in free service (needs internet); everything else — cards, storage, review — works fully offline
* Progress is stored **on the phone** (per-app storage), independent of the website account
* **Fixed 510dp layout** — `width=510` viewport + `UseWideViewPort` + `LoadWithOverviewMode` + `setInitialScale(dpW*100/510)` + `enforceFixedViewport()` — same as LitReader
* **Immersive mode** — sticky fullscreen, status+nav hidden, swipe to peek (`com.studypal.app.IMMERSIVE=true`)
* Manifest flags (no Java edits needed):
  `com.studypal.app.IMMERSIVE`, `com.studypal.app.EDGE_TO_EDGE` (off — the page is not edge-aware),
  `com.studypal.app.DARK_MODE`, `com.studypal.app.PULL_REFRESH`,
  `com.studypal.app.DESKTOP_SITE` — `true/false` or `1/0`
* Mic permission for voice answers, file picker for import, native save-to-Downloads for export

Note: because the app is a frozen copy, editing the generator here does **not** update the app — re-copy `index.html` (+ rebuilt CSS) into `assets/www/` and rebuild for a new version.

## Build it in the cloud

Phone-only (no extract):
1. Upload `studypal-app.zip` to the repo ROOT as-is.
2. Put both workflow files in `.github/workflows/` (`build-apk.yml`, `build-apk-from-zip.yml`).
3. Actions → **Build StudyPal APK (zip upload)** → Run workflow. Wait 5–10 min.
4. Download `studypal-apk` artifact → install (allow unknown apps once).

Extracted:
1. Upload the *contents* so `settings.gradle` sits at `/`.
2. Actions → **Build StudyPal APK** → runs on push. Wait 5–10 min.
3. Download `studypal-apk` → install over old.

All builds sign with `studypal-debug.p12` in repo root — keep it, so updates install over the old app without uninstall.

## Point it at your own fork

Change `com.studypal.app.URL` in `app/src/main/AndroidManifest.xml` to your fork's `https://perchance.org/...` link. A fork keeps working when the original changes.
