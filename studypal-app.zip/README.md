# StudyPal AI — Android app

Wraps the **StudyPal AI** generator (`https://perchance.org/studypal2`), packaged like LitReader:

* WebView opens the online generator (AI flashcards, quiz, podcast, tutor need internet)
* Local `www/index.html` is the offline fallback with a retry button
* **Fixed 510dp layout** — `width=510` viewport + `UseWideViewPort` + `LoadWithOverviewMode` + `setInitialScale(dpW*100/510)` + `enforceFixedViewport()` — same as LitReader, so changing smallest-width never reshapes the app
* **Immersive mode** — sticky fullscreen, status+nav hidden, swipe to peek (`com.studypal.app.IMMERSIVE=true`)
* Manifest flags (no Java edits needed):
  `com.studypal.app.IMMERSIVE`, `com.studypal.app.EDGE_TO_EDGE` (off — StudyPal page is not edge-aware),
  `com.studypal.app.DARK_MODE`, `com.studypal.app.PULL_REFRESH`,
  `com.studypal.app.DESKTOP_SITE` — `true/false` or `1/0`
* Mic permission for voice answers/podcast, file picker for import/export

## Build it in the cloud (recommended)

Phone-only (no extract):
1. Upload `studypal-app.zip` to the repo ROOT as-is.
2. Add `build-apk-from-zip.yml` to `.github/workflows/` (from this zip).
3. Actions → **Build StudyPal APK (zip upload)** → Run workflow. Wait 5–10 min.
4. Download `studypal-apk` artifact → install (allow unknown apps once).

Extracted:
1. Upload the *contents* so `settings.gradle` sits at `/`.
2. Actions → **Build StudyPal APK** → runs on push. Wait 5–10 min.
3. Download `studypal-apk` → install over old.

All builds sign with `studypal-debug.p12` in repo root — keep it, so updates install over the old app without uninstall.

## Point it at your own fork

Default URL is `https://perchance.org/studypal2` (`com.studypal.app.URL` in the manifest).
To wrap your own fork instead, change that value. A forked generator keeps working when the original changes.
